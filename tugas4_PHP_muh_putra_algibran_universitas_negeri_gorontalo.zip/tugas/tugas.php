<?php
$username = $_POST['username'];
$password = $_POST['password'];

function cekLogin(){

    if ($username == 'admin' && $password == 'mimin'){
        header("location:latihan_frame_link/index.html");
    } else {
        echo "<script>alert('Username atau Password Salah !!');</script>";
    }
}

if(isset($_POST['login'])) cekLogin($_POST['username'],$_POST['password']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>


</head>
<body bgcolor="badadd">
    <div class="container">
            <ul>
                <form action="" method="POST">
                <table width="40%" align="center" cellpadding="5" cellspacing="0" bgcolor="lightblue">
                <thead>
                <th bgcolor="#skyblue">
                    <h3 align="center">Log In</h3>
                </th>
            </thead>
                    <tr>
                        <td><label for="username">Username</label></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="username" id="username"></td>
                    </tr>
                    <tr>
                        <td><label for="password">Password : </label></td>
                    </tr>
                    <tr>
                        <td><input type="password" name="password"></td>
                    </tr>
                    <tr>
                        <td><input type="submit" onclick="<?php cekLogin($username,$password) ?>" name="sign-in" value="Sign-in" /></td>
                    </tr>
                </table>
                </form>
            </ul>
    </div>
</body>
</html>
